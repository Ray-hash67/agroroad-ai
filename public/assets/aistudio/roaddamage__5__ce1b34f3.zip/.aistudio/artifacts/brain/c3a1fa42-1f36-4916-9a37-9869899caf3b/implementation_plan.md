# Dashboard Element Deletion & Layout Refinement

## Summary
The user selected elements on the primary dashboard (`main > div > div:nth-of-type(1)`, covering the Interactive Map card, the Recent Detections panel, and header controls) requesting to "delete it in my website". This plan specifies the removal of the targeted component to achieve the user's desired clean layout.

## User Review & Critical Decisions

> [!IMPORTANT]
> Because multiple elements spanning the middle dashboard grid were selected in Focus Mode, we have prepared two clean layout execution paths for your approval:
> 
> 1. **Option A (Recommended — Full-Width Map)**: Delete the **Recent Detections** side-panel (`Selector 2`), expanding the **Interactive Satellite Map** to 100% full width across the entire dashboard.
> 2. **Option B (Full Reset / Single-Focus Map)**: Remove the entire selected dashboard container (`Selector 1`), redirecting the primary dashboard tab directly into the dedicated full-screen GIS satellite explorer view.

---

### 1. Overview & Core Concept
- **Current State**: The dashboard currently displays an asymmetric 8:4 column grid containing the Interactive Map (left 8 cols) and Recent Detections list (right 4 cols).
- **Target Experience**: Streamlined single-focus dashboard interface that removes visual clutter, expanding spatial mapping visibility across the viewport.

---

### 2. User Experience & Visual Design
- **Expanded Map Viewport**: The GIS Satellite map expands from 8-column width to full 12-column container width (`w-full`), providing maximum geographic context across Phnom Penh corridors.
- **Header Cleanliness**: Streamline header badges and action controls (`Selectors 3, 4, 5`) to retain only essential satellite layer controls.
- **Responsive Layout**: Maintains clean mobile and desktop responsive heights (`h-[calc(100vh-160px)]`) with zero unnecessary scrollbars.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Removal of Recent Detections Panel vs. Entire Grid**
  - *Chosen Approach*: Remove the right-hand Recent Detections panel (`Selector 2`) from the dashboard and expand the map to 100% width. All inspection records remain fully accessible via the **Data Management** and **Reports** tabs in the sidebar.
  - *Why*: Prevents leaving a completely blank screen while fulfilling the deletion request cleanly.

- **Decision 2: Header Control Streamlining**
  - *Chosen Approach*: Clean up redundant subtitle labels and extra buttons identified in `Selectors 2, 3, 4, 5`.

---

### 4. Technical Architecture & Implementation Steps

```
┌─────────────────────────────────────────────────────────────┐
│                       AgroRoad AI                           │
│  [Sidebar Navigation]  │   [Header: Date / Lang / Profile]  │
├────────────────────────┴─────────────────────────────────────┤
│                                                             │
│  Interactive Satellite Map (Full 100% Width)                │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                                                       │  │
│  │   Phnom Penh High-Resolution GIS Satellite Canvas     │  │
│  │   - Pothole, Alligator & Manhole Markers              │  │
│  │   - Full-Screen Viewport                              │  │
│  │                                                       │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

1. **Modify `src/App.tsx`**:
   - Update the `case 'dashboard'` render function.
   - Remove the 4-column `RecentDetectionsList` panel from the dashboard grid.
   - Expand `InteractiveMap` to span the full 12 columns (`col-span-12 w-full h-[calc(100vh-140px)]`).
2. **Verify Verification & Compilation**:
   - Run `lint_applet` and `compile_applet`.
   - Verify dev server responsiveness on port 3000.
