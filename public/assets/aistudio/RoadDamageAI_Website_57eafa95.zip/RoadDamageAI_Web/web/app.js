(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const labels = {D00: "Longitudinal crack", D10: "Transverse crack", D20: "Alligator crack", D40: "Pothole"};
  const colors = {D00: "#5dd2bb", D10: "#60bdec", D20: "#e0b87a", D40: "#e58d8f"};
  let modelReady = false;
  let inspections = [];
  let selectedFile = null;
  let previewURL = null;
  let leafletMap = null;
  let leafletLayer = null;
  let toastTimer = null;

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
  const shortDate = (iso) => { try { return new Date(iso).toLocaleString(undefined, {dateStyle:"medium", timeStyle:"short"}); } catch { return iso; } };
  const n = (value) => Number(value || 0).toLocaleString();
  function toast(message, error = false) {
    const el = $("toast"); el.textContent = message; el.className = `toast show${error ? " error" : ""}`;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.className = "toast", 5400);
  }
  async function request(path, options = {}) {
    let res;
    try { res = await fetch(path, options); } catch { throw new Error("Cannot connect to the website API. Start server.py first."); }
    let payload = null;
    try { payload = await res.json(); } catch { /* handle empty response */ }
    if (!res.ok) {
      let detail = payload?.detail || `HTTP ${res.status}`;
      if (Array.isArray(detail)) detail = detail.map((item) => item.msg).join("; ");
      throw new Error(detail);
    }
    return payload;
  }
  async function getData() {
    try {
      const [health, stats, rows] = await Promise.all([
        request("/api/health"), request("/api/stats"), request("/api/inspections?limit=500")
      ]);
      modelReady = !!health.model.ready;
      $("model-badge").innerHTML = `<span class="status-point"></span>${modelReady ? "Model available" : "Model not trained"}`;
      $("model-badge").classList.toggle("ready", modelReady);
      $("sidebar-status").textContent = modelReady ? "Model weights available" : "Awaiting trained weights";
      document.querySelector(".pulse-dot").classList.toggle("ready", modelReady);
      $("no-model-notice").classList.toggle("ready", modelReady);
      $("no-model-notice").querySelector("strong").textContent = modelReady ? "Custom weights detected" : "AI detection requires trained weights";
      $("model-notice-text").textContent = health.model.message;
      $("setup-status-title").textContent = modelReady ? "Custom model file found" : "Custom model not yet installed";
      $("setup-status-text").textContent = health.model.message;
      $("analyze-button").disabled = !modelReady || !selectedFile;
      renderStats(stats);
      inspections = rows;
      renderRecent(); renderHistory(); if (leafletMap) renderMap();
    } catch (err) {
      toast(err.message, true);
      $("sidebar-status").textContent = "API offline";
      $("model-badge").textContent = "API offline";
      $("model-notice-text").textContent = "Run the Python server to enable saving and inference.";
      $("setup-status-title").textContent = "Backend not connected";
      $("setup-status-text").textContent = "Start the server using the supplied launcher.";
    }
  }
  function renderStats(stats) {
    $("stat-inspections").textContent = n(stats.inspections);
    $("stat-detections").textContent = n(stats.ai_observations);
    $("stat-manual").textContent = n(stats.manual_reports);
    $("stat-mapped").textContent = n(stats.mapped_inspections);
    const max = Math.max(...Object.values(stats.counts), 1);
    $("damage-bars").innerHTML = Object.entries(labels).map(([code,label]) => {
      const val = Number(stats.counts[code] || 0);
      const pct = val === 0 ? 0 : Math.max(3, 100*val/max);
      return `<div class="bar-item"><span class="bar-label"><i style="background:${colors[code]}"></i>${escapeHtml(label)}</span><div class="bar-track"><div class="bar-fill" style="background:${colors[code]};width:${pct}%"></div></div><span class="bar-value">${n(val)}</span></div>`;
    }).join("");
  }
  function renderRecent() {
    const top = inspections.slice(0, 5);
    $("recent-list").innerHTML = top.length ? top.map((item) => `<div class="recent-item"><div class="recent-icon">${item.mode === "manual" ? "▤" : "⌗"}</div><div><div class="recent-name">${escapeHtml(item.source_file)}</div><div class="recent-sub">${item.mode === "manual" ? "Manual field report" : "AI inspection"} · ${escapeHtml(shortDate(item.created_at))}</div></div><button class="recent-action" data-detail="${item.id}">Review →</button></div>`).join("") : `<div class="empty">No inspections saved yet. Start with an image or create a field report.</div>`;
  }
  function renderHistory() {
    const term = $("record-search").value.trim().toLowerCase();
    const results = inspections.filter((item) => `${item.source_file} ${item.id} ${item.mode} ${item.damage_code || ""}`.toLowerCase().includes(term));
    $("records-body").innerHTML = results.length ? results.map((item) => `<tr><td><strong>${escapeHtml(item.source_file)}</strong><small>${escapeHtml(item.id)}</small></td><td><span class="table-pill ${item.mode === "manual" ? "manual" : ""}">${item.mode === "manual" ? "MANUAL" : "AI · " + escapeHtml(item.medium.toUpperCase())}</span></td><td>${escapeHtml(shortDate(item.created_at))}</td><td>${item.mode === "manual" ? "—" : n(item.detection_count)}</td><td>${item.latitude !== null ? "GPS recorded" : "Not mapped"}</td><td><button class="view-button" data-detail="${item.id}">View details →</button></td></tr>`).join("") : `<tr><td colspan="6"><div class="empty">No matching inspection records.</div></td></tr>`;
  }
  const navNames = {overview:"Overview", inspect:"AI inspection",history:"Inspection records",map:"GIS mapping",setup:"Model & settings"};
  function gotoPage(page) {
    if (!navNames[page]) return;
    document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === `page-${page}`));
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.page === page));
    $("breadcrumb").textContent = navNames[page];
    document.title = `${navNames[page]} · RoadDamage AI`;
    history.replaceState(null, "", `#${page}`);
    window.scrollTo({top:0,behavior:"instant"});
    if (page === "map") setTimeout(initializeMap, 70);
  }
  document.querySelectorAll("[data-page]").forEach((el) => el.addEventListener("click", () => gotoPage(el.dataset.page)));
  document.querySelectorAll("[data-go]").forEach((el) => el.addEventListener("click", () => gotoPage(el.dataset.go)));
  window.addEventListener("hashchange", () => gotoPage(location.hash.replace("#", "") || "overview"));

  const drop = $("drop-zone");
  drop.addEventListener("click", () => $("file-input").click());
  drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("file-input").click(); } });
  ["dragenter","dragover"].forEach((event) => drop.addEventListener(event, (e) => {e.preventDefault();drop.classList.add("dragover");}));
  ["dragleave","drop"].forEach((event) => drop.addEventListener(event, (e) => {e.preventDefault();drop.classList.remove("dragover");}));
  drop.addEventListener("drop", (e) => setFile(e.dataTransfer.files[0]));
  $("file-input").addEventListener("change", (e) => setFile(e.target.files[0]));
  $("remove-file").addEventListener("click", () => setFile(null));
  $("confidence").addEventListener("input", () => $("confidence-value").textContent = Number($("confidence").value).toFixed(2));
  function setFile(file) {
    if (previewURL) { URL.revokeObjectURL(previewURL); previewURL = null; }
    selectedFile = file || null;
    $("result-empty").classList.remove("hidden");
    $("result-content").classList.add("hidden");
    if (!file) {
      $("media-preview").classList.add("hidden"); $("file-input").value = "";
    } else {
      const ext = file.name.split(".").pop().toLowerCase();
      const isVideo = ["mp4","mov","avi","mkv"].includes(ext);
      if (!["jpg","jpeg","png","webp","mp4","mov","avi","mkv"].includes(ext)) { toast("Unsupported media file type.", true); selectedFile=null; return; }
      if (file.size > (isVideo ? 100 : 20) * 1024 * 1024) { toast("File is larger than the allowed size.", true); selectedFile=null; return; }
      $("filename").textContent = file.name;
      $("file-size").textContent = `${(file.size / 1024 / 1024).toFixed(2)} MB`;
      previewURL = URL.createObjectURL(file);
      $("preview-host").replaceChildren();
      const media = document.createElement(isVideo ? "video" : "img");
      media.src = previewURL;
      if (isVideo) media.controls = true;
      media.alt = "Selected road inspection image";
      $("preview-host").append(media);
      $("media-preview").classList.remove("hidden");
      $("stride").disabled = !isVideo;
    }
    $("analyze-button").disabled = !modelReady || !selectedFile;
  }
  function getOptionalCoords(latId, lonId) {
    const latRaw = $(latId).value.trim(), lonRaw = $(lonId).value.trim();
    if (!!latRaw !== !!lonRaw) throw new Error("Both latitude and longitude must be provided together.");
    if (!latRaw) return [null,null];
    const lat = Number(latRaw), lon = Number(lonRaw);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new Error("Invalid GPS coordinates.");
    return [lat,lon];
  }
  $("analyze-button").addEventListener("click", async () => {
    if (!selectedFile || !modelReady) return;
    let coords;
    try { coords = getOptionalCoords("ai-lat", "ai-lon"); } catch (err) { toast(err.message,true); return; }
    const data = new FormData();
    data.append("file", selectedFile); data.append("confidence", $("confidence").value);
    const ext = selectedFile.name.split(".").pop().toLowerCase();
    const isVideo = ["mp4","mov","avi","mkv"].includes(ext);
    if (isVideo) data.append("stride", $("stride").value);
    if (coords[0] !== null) { data.append("latitude",coords[0]); data.append("longitude",coords[1]); }
    $("analyze-button").disabled = true; $("analyze-progress").classList.remove("hidden");
    try {
      const item = await request(isVideo ? "/api/inspect/video" : "/api/inspect/image", {method:"POST", body:data});
      showInferenceResult(item); toast("Inspection completed and saved."); await getData();
    } catch (err) { toast(err.message,true); }
    finally { $("analyze-progress").classList.add("hidden"); $("analyze-button").disabled = !modelReady || !selectedFile; }
  });
  function showInferenceResult(item) {
    $("result-empty").classList.add("hidden");
    const host = $("result-content"); host.classList.remove("hidden");
    const media = item.medium === "video" ? `<video src="${item.files.annotated}" controls preload="metadata"></video>` : `<img src="${item.files.annotated}" alt="Annotated real AI detection result">`;
    host.innerHTML = `<div class="result-visual">${media}</div><div class="result-desc"><strong>${n(item.detection_count)} detection observations</strong> · ${escapeHtml(item.source_file)} · ${escapeHtml(shortDate(item.created_at))}</div><div class="results-counts">${Object.entries(labels).map(([code, label]) => `<div><span>${escapeHtml(label)}</span><strong>${n(item.counts[code] || 0)}</strong></div>`).join("")}</div><p class="small-disclaimer">No detections does not prove the pavement is undamaged. Video counts may include repeated observations of one defect.</p><div class="result-actions"><a href="${item.files.annotated}" download class="btn btn-secondary compact">↓ Annotated media</a><a href="${item.files.csv}" download class="btn btn-outline compact">↓ Detection CSV</a><button class="btn btn-outline compact" data-detail="${item.id}">View details</button></div>`;
  }
  $("manual-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    let lat, lon;
    try { [lat,lon] = getOptionalCoords("manual-lat", "manual-lon"); } catch (err) { toast(err.message,true); return; }
    const button = $("manual-form").querySelector("button[type=submit]"); button.disabled = true;
    try {
      await request("/api/inspections/manual", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        source_file:$("manual-road").value,damage_code:$("manual-code").value,
        severity:$("manual-severity").value,note:$("manual-note").value,latitude:lat,longitude:lon
      })});
      $("manual-form").reset();toast("Manual road defect report saved.");await getData();
    } catch (err) { toast(err.message,true); }
    finally { button.disabled = false; }
  });
  $("record-search").addEventListener("input", renderHistory);
  document.addEventListener("click", (event) => {
    const el = event.target.closest("[data-detail]");
    if (el) showDetail(el.dataset.detail);
  });
  $("close-modal").addEventListener("click", () => $("detail-modal").close());
  async function showDetail(id) {
    try {
      const item = await request(`/api/inspections/${encodeURIComponent(id)}`);
      const rows = [
        ["Source",item.source_file], ["Method",item.mode === "manual" ? "Manual field report" : "AI detection"],
        ["Date",shortDate(item.created_at)], ["Medium",item.medium],
        ["AI observations",item.mode === "manual" ? "Not applicable" : n(item.detection_count)],
        ["Damage classes",Object.entries(item.counts).map(([code,val]) => `${code}: ${val}`).join(" · ") || "None"],
        ["GPS coordinates",item.latitude === null ? "Not entered" : `${item.latitude}, ${item.longitude}`],
        ["Human-assigned priority",item.severity || "Not assigned"], ["Notes",item.note || "—"]
      ];
      $("detail-body").innerHTML = rows.map(([label,value]) => `<div class="modal-field"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("") +
        `<div class="modal-actions">${Object.entries(item.files).filter(([key]) => key !== "original").map(([kind,url]) => `<a class="btn btn-outline compact" href="${escapeHtml(url)}" download>↓ ${escapeHtml(kind)}</a>`).join("")}</div>`;
      $("detail-modal").showModal();
    } catch (err) { toast(err.message,true); }
  }
  function initializeMap() {
    if (!window.L) {
      $("map").innerHTML = `<div class="empty" style="padding:30px">Map tiles could not load. Internet access is required for this view. Your GeoJSON and CSV exports work offline.</div>`;
      return;
    }
    if (!leafletMap) {
      leafletMap = L.map("map", {scrollWheelZoom:false}).setView([11.5564,104.9282], 12);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',maxZoom:19}).addTo(leafletMap);
      leafletLayer = L.layerGroup().addTo(leafletMap);
    }
    leafletMap.invalidateSize(); renderMap();
  }
  function renderMap() {
    if (!leafletMap) return;
    leafletLayer.clearLayers();
    const valid = inspections.filter((item) => item.latitude !== null && item.longitude !== null);
    $("map-count").textContent = `${valid.length} LOCATIONS`;
    const bounds = [];
    valid.forEach((item) => {
      const marker = L.circleMarker([item.latitude,item.longitude], {radius:8,color:item.mode === "manual" ? "#e0b87a" : "#5ee2b6",fillColor:item.mode === "manual" ? "#e0b87a" : "#5ee2b6",fillOpacity:.72,weight:2}).addTo(leafletLayer);
      marker.bindPopup(`<strong>${escapeHtml(item.source_file)}</strong><br>${item.mode === "manual" ? "Manual field report" : "AI inspection"}<br>${escapeHtml(shortDate(item.created_at))}<br>${item.mode === "manual" ? escapeHtml(labels[item.damage_code] || "") : `${n(item.detection_count)} observations`}<br><small>Inspection coordinate, not defect GPS</small>`);
      bounds.push([item.latitude,item.longitude]);
    });
    if (bounds.length) leafletMap.fitBounds(bounds,{padding:[35,35],maxZoom:15});
  }
  gotoPage(location.hash.replace("#", "") || "overview");
  getData();
})();
