@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (set "PY=py") else (set "PY=python")
if not exist .venv ( %PY% -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 ( echo Dependency installation failed. & pause & exit /b 1 )
echo.
echo Website: http://127.0.0.1:8000
echo Keep this window running.
start "" "http://127.0.0.1:8000"
python -m uvicorn server:app --host 127.0.0.1 --port 8000
pause
