# RoadDamage AI — Full Website (local-first starter)

A responsive browser-based road condition monitoring website with **actual image/video inference only when a compatible trained model is installed**, plus manual field reporting, an inspection library, CSV/GeoJSON downloads, and an OpenStreetMap map.

## What is functional

- **Overview:** real stored totals, damage class distribution, recent inspections.
- **AI inspection:** road image (.jpg, .jpeg, .png, .webp) and video (.mp4, .mov, .avi, .mkv). YOLO inference runs on the Python server, saves annotated evidence, and exports detection observations. Requires your trained `best.pt` weights.
- **Manual report:** create real field reports (D00/D10/D20/D40), optional GPS, priority, road name, and notes; works immediately without a trained model.
- **Inspection records:** history persists in local SQLite, with source media for AI reports.
- **GIS map:** displays GPS-tagged inspection locations on OpenStreetMap tiles (internet needed for tiles) and GeoJSON export. GPS is an **inspection point**, not individual defect coordinates.
- **Model setup:** explains dataset and training.

No fabricated AI detections or invented inspection counts. Video detection counts are per-frame observations and may repeat the same physical defect. Confidence is not a severity estimate.

## Quick start (Windows)

1. Install [Python 3.11](https://www.python.org/downloads/) (enable **Add python.exe to PATH**).
2. Extract this ZIP, then double-click **`launch_windows.bat`**.
3. The launcher installs dependencies and opens **http://127.0.0.1:8000**.
4. Add your road image, use the manual report form, or load a trained model as described below.

First installation may take several minutes and needs an internet connection. Close the terminal window to stop the web server.

## macOS/Linux

```bash
cd RoadDamageAI_Web
chmod +x launch_mac_linux.sh
./launch_mac_linux.sh
```

Or, with a preconfigured environment:

```bash
pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8000
```

> Opening `web/index.html` by double click won't connect to the backend API. **Start the Python server** and use `http://127.0.0.1:8000` instead.

## Enable trained AI detection

The ZIP deliberately **does not include `best.pt`**. A generic object-detection model (e.g. COCO) does not detect the four RDD2022 pavement classes. The website rejects incompatible model class mappings.

Expected classes:

| ID | Code | Class |
|---|---|---|
| 0 | D00 | Longitudinal crack |
| 1 | D10 | Transverse crack |
| 2 | D20 | Alligator crack |
| 3 | D40 | Pothole |

Option A: `Colab_Train_RoadDamageAI.ipynb` for training on a GPU in Google Colab.

Option B: dataset preprocessing/training locally:

```bash
# Example: official RDD2022 images and XML annotations already extracted at /path/to/RDD2022
python tools/prepare_rdd2022.py --source /path/to/RDD2022 --output dataset
python tools/train.py --data dataset/data.yaml --model yolo26s.pt --epochs 100 --imgsz 640 --batch 8
```

The preprocessor creates its own `dataset/data.yaml`; you can use this directly. Use held-out **road segments/capture sessions** when evaluating to reduce leakage from neighboring frames. If your dataset is already exported in YOLO format, skip conversion. The folder `data.yaml` in this repo is merely a class mapping example.

After training, locate `runs/road_damage_v1/weights/best.pt`. Copy it to:

```
RoadDamageAI_Web/models/best.pt
```

Restart the backend server. The model loads lazily on first inference, so model validation happens then. The UI will indicate model availability once the file and dependencies are installed. For evaluation:

```bash
python tools/evaluate.py --help
```

## Upload limits and GIS semantics

- Images: 20MB, max 25 megapixels; videos: 100MB.
- GPS coordinates are optional. If entered, each inspection is represented by one map point; **no claims of pixel-to-ground defect localization** are made.
- Manual severity labels are human-entered. The AI does not infer engineering priority from object detection confidence.
- Model confidence threshold is configurable; minimum 0.05 / maximum 0.95.
- Video `frame stride` samples every Nth frame, retains original playback frames, and counts observations per analyzed frame. A unique-defect tracker is not included.
- API docs (once server is running): http://127.0.0.1:8000/api/docs

## Storage and privacy

- Local SQLite: `data/inspections.sqlite3`.
- Uploaded originals: `data/uploads/`.
- AI annotated outputs and CSV: `data/outputs/`.
- Clear these to erase locally stored inspection media and records **only after backing up anything you need**.
- The web frontend loads Google Fonts and Leaflet/OpenStreetMap map tiles from third-party hosts (if internet is available). Field data remains on the server unless you export or deploy it; tiles can expose your device's IP address and viewed map area to tile providers.

## Hosting your own website

This ZIP is **locally runnable**, not a hosted/public URL. To deploy the Python API, use a platform that supports long-running Python servers and persistent storage. In production you need at minimum:

1. A secure authenticated user system and HTTPS (this starter has **no user login**).
2. Rate limiting and upload scanning/validation; restrict public API access.
3. Persistent database and media storage (SQLite and disk storage are local development defaults; ephemeral hosts can lose them).
4. Appropriate compute (possibly GPU) for YOLO image/video inference. Video analysis is synchronous and could require a job queue to handle long workloads.
5. Domain/SSL configuration and backup/retention rules.

**Do not expose this unauthenticated API on the public Internet as is**, especially with user photos or coordinates. The launcher binds to `127.0.0.1` to keep the website on your own computer.

## Structure

```
RoadDamageAI_Web/
├── server.py                 # FastAPI backend and local database
├── core.py                   # Trained-only YOLO inference and export helpers
├── web/
│   ├── index.html            # Responsive dashboard and pages
│   ├── styles.css            # UI styling
│   └── app.js                # API integrations, media preview, map
├── models/                   # Place your custom best.pt here
├── data/                     # SQLite, uploaded images and results (runtime)
├── tools/                    # Dataset conversion, training and validation
├── Colab_Train_RoadDamageAI.ipynb
├── launch_windows.bat
├── launch_mac_linux.sh
└── requirements.txt
```

## Scientific and operational limitations

This is a **proof-of-concept inspection tool**, not an autonomous pavement engineering certification system. RDD2022 is a useful public dataset but road appearance and camera conditions vary; verify on local road samples and report per-class precision/recall and mAP50-95. Require field review before using detections for repair decisions.
