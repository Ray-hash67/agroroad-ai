"""Evaluate a trained RDD2022 model on held-out YOLO test images."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import get_model


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--weights", default="models/best.pt")
    ap.add_argument("--data", required=True)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--output", default="evaluation.json")
    a = ap.parse_args()
    model, _mapping = get_model(a.weights)
    metrics = model.val(data=str(Path(a.data).resolve()), split="test", imgsz=a.imgsz, device=a.device)
    report = {
        "model": a.weights, "data": a.data,
        "precision": float(metrics.box.mp),
        "recall": float(metrics.box.mr),
        "mAP50": float(metrics.box.map50),
        "mAP50_95": float(metrics.box.map),
        "note": "Metrics from held-out dataset; validate by trip/road to avoid frame leakage.",
    }
    Path(a.output).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
