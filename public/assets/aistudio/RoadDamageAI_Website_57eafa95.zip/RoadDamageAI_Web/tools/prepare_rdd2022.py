"""Convert official RDD2022 Pascal VOC annotations into four-class YOLO data.

Usage:
    python tools/prepare_rdd2022.py --source /path/to/RDD2022 --output dataset

Official challenge test images have no ground-truth XML and are deliberately
excluded. We create internal training/validation/test splits from labeled
images. For research, hold out entire trips or locations instead when possible.
"""
from __future__ import annotations

import argparse
import json
import random
import re
import shutil
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

from PIL import Image

CODES = {"D00": 0, "D10": 1, "D20": 2, "D40": 3}
EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
KNOWN_COUNTRIES = {"japan", "india", "czech", "norway", "united_states", "unitedstates", "usa", "china", "chinamotorbike", "chinadrone"}


def country_of(path: Path, root: Path) -> str:
    """Recover country folder to avoid collisions across the RDD dataset."""
    for part in path.relative_to(root).parts:
        norm = "".join(c for c in part.lower() if c.isalnum() or c == "_")
        if norm in KNOWN_COUNTRIES or any(norm.startswith(k) for k in KNOWN_COUNTRIES):
            return norm
    return root.name.lower()


def parse_voc(xml_path: Path, image_path: Path) -> list[str]:
    tree = ET.parse(xml_path)
    with Image.open(image_path) as im:
        width, height = im.size
    if width < 2 or height < 2:
        raise ValueError("Invalid image dimensions")
    lines = []
    for obj in tree.findall(".//object"):
        name = (obj.findtext("name") or "").strip().upper()
        if name not in CODES:
            continue
        box = obj.find("bndbox")
        if box is None:
            continue
        try:
            x1 = float(box.findtext("xmin"))
            y1 = float(box.findtext("ymin"))
            x2 = float(box.findtext("xmax"))
            y2 = float(box.findtext("ymax"))
        except (ValueError, TypeError):
            continue
        x1 = min(max(x1, 0), width)
        x2 = min(max(x2, 0), width)
        y1 = min(max(y1, 0), height)
        y2 = min(max(y2, 0), height)
        if x2 <= x1 or y2 <= y1:
            continue
        cx = (x1 + x2) / 2 / width
        cy = (y1 + y2) / 2 / height
        bw = (x2 - x1) / width
        bh = (y2 - y1) / height
        lines.append(f"{CODES[name]} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")
    return lines


def group_key(country: str, stem: str, regex: str | None) -> str:
    if not regex:
        return f"{country}/{stem}"
    match = re.search(regex, stem)
    # Matched IDs should represent independent road/video capture groups.
    return f"{country}/{match.group(1) if match and match.groups() else match.group(0) if match else stem}"


def assign_groups(rows: list[dict], seed: int, regex: str | None) -> dict[int, str]:
    rng = random.Random(seed)
    groups = defaultdict(list)
    for idx, row in enumerate(rows):
        groups[group_key(row["country"], row["stem"], regex)].append(idx)
    keys = sorted(groups)
    rng.shuffle(keys)
    # Group-based split if a regex is supplied, otherwise image-level split.
    split_idx: dict[int, str] = {}
    total = len(rows)
    n_train, n_val = round(total * 0.70), round(total * 0.15)
    counts = Counter()
    for key in keys:
        group = groups[key]
        if counts["train"] < n_train:
            split = "train"
        elif counts["val"] < n_val:
            split = "val"
        else:
            split = "test"
        for idx in group:
            split_idx[idx] = split
        counts[split] += len(group)
    return split_idx


def convert(source: Path, output: Path, seed: int = 42, group_regex: str | None = None) -> dict:
    if not source.is_dir():
        raise FileNotFoundError(f"RDD2022 source directory not found: {source}")
    if source.resolve() == output.resolve() or source.resolve() in output.resolve().parents:
        raise ValueError("Output must not be inside the source directory (would affect future runs).")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Output folder already contains files: {output}. Use a new output path or clear it first.")
    image_index = defaultdict(list)
    for file in source.rglob("*"):
        if file.is_file() and file.suffix.lower() in EXTS:
            image_index[(country_of(file, source), file.stem.lower())].append(file)
    if not image_index:
        raise RuntimeError("No images found in the source folder.")

    rows, not_found, ambiguous, invalid, empty = [], 0, 0, 0, 0
    xmls = sorted(source.rglob("*.xml"))
    if not xmls:
        raise RuntimeError("No Pascal VOC XML files found. The official challenge test set has no labels.")
    for xml_file in xmls:
        country = country_of(xml_file, source)
        image_matches = image_index.get((country, xml_file.stem.lower()), [])
        if not image_matches:
            not_found += 1
            continue
        if len(image_matches) > 1:
            # Choose the image that shares the most folder-prefix parts with the XML.
            def similarity(path):
                return len(set(path.relative_to(source).parts) & set(xml_file.relative_to(source).parts))
            image_matches.sort(key=similarity, reverse=True)
            if len(image_matches) >= 2 and similarity(image_matches[0]) == similarity(image_matches[1]):
                ambiguous += 1
                continue
        path = image_matches[0]
        try:
            lines = parse_voc(xml_file, path)
        except (ET.ParseError, ValueError, OSError):
            invalid += 1
            continue
        if not lines:
            empty += 1
        rows.append({"image": path, "country": country, "stem": path.stem, "labels": lines})
    if len(rows) < 10:
        raise RuntimeError(
            f"Only {len(rows)} labeled images matched. Verify that your RDD2022 folder "
            "includes both images and annotation XML files for the train countries."
        )
    splits = assign_groups(rows, seed, group_regex)
    if set(splits.values()) != {"train", "val", "test"}:
        raise ValueError("Data split did not yield all train/val/test sets. Check --group-regex and add more independent image groups.")
    used = Counter()
    damage_counts = Counter()
    for i, row in enumerate(rows):
        split = splits[i]
        src = row["image"]
        country_slug = re.sub(r"[^a-zA-Z0-9_-]", "_", row["country"])
        basename = re.sub(r"[^a-zA-Z0-9_-]", "_", row["stem"])
        stem = f"{country_slug}_{basename}"
        target_img = output / "images" / split / (stem + src.suffix.lower())
        target_label = output / "labels" / split / (stem + ".txt")
        # If same stem reused across image formats or folders, append stable index.
        if target_img.exists() or target_label.exists():
            stem = f"{stem}_{i:06d}"
            target_img = output / "images" / split / (stem + src.suffix.lower())
            target_label = output / "labels" / split / (stem + ".txt")
        target_img.parent.mkdir(parents=True, exist_ok=True)
        target_label.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target_img)
        target_label.write_text("\n".join(row["labels"]) + ("\n" if row["labels"] else ""), encoding="utf-8")
        used[split] += 1
        for label in row["labels"]:
            damage_counts[label.split(" ")[0]] += 1
    data_yaml = (
        f'path: "{output.resolve().as_posix()}"\n'
        "train: images/train\nval: images/val\ntest: images/test\n"
        "names:\n  0: D00\n  1: D10\n  2: D20\n  3: D40\n"
    )
    (output / "data.yaml").write_text(data_yaml, encoding="utf-8")
    report = {
        "images": dict(used), "bounding_boxes_by_class": dict(damage_counts),
        "matched_xml": len(rows), "unmatched_xml": not_found,
        "ambiguous_xml": ambiguous, "invalid_xml": invalid,
        "images_without_target_boxes": empty,
        "group_regex": group_regex,
        "note": "Official unlabeled challenge test images excluded. For publication-grade evaluation split by trip/location to reduce leakage.",
    }
    (output / "conversion_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", required=True, type=Path, help="Extracted RDD2022 root folder")
    p.add_argument("--output", default="dataset", type=Path)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--group-regex", default=None, help="Optional regex to hold images from one video/road segment together (first capture group used)")
    a = p.parse_args()
    print(json.dumps(convert(a.source, a.output, a.seed, a.group_regex), indent=2))
    print(f"Dataset YAML: {(a.output / 'data.yaml').resolve()}")


if __name__ == "__main__":
    main()
