"""Fine-tune YOLO26 on an RDD2022 4-class YOLO-format dataset."""
from __future__ import annotations
import argparse
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", required=True, help="YOLO dataset/data.yaml")
    ap.add_argument("--model", default="yolo26n.pt", help="e.g. yolo26n.pt or yolo26s.pt")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--patience", type=int, default=20)
    ap.add_argument("--device", default=None, help="e.g. 0 or cpu; autodetect by default")
    ap.add_argument("--name", default="road_damage_v1")
    args = ap.parse_args()
    data = Path(args.data).resolve()
    if not data.is_file():
        ap.error(f"Dataset YAML not found: {data}")
    from ultralytics import YOLO
    import torch
    device = args.device if args.device is not None else ("0" if torch.cuda.is_available() else "cpu")
    print(f"Training on {device} | dataset={data} | model={args.model}")
    model = YOLO(args.model)
    model.train(
        data=str(data), epochs=args.epochs, imgsz=args.imgsz,
        batch=args.batch, patience=args.patience,
        project="runs", name=args.name, device=device, seed=42,
        plots=True, exist_ok=True,
    )
    print(f"\nFinished. Look for runs/{args.name}/weights/best.pt")
    print("Copy best.pt into the models/ directory and restart the website server.")


if __name__ == "__main__":
    main()
