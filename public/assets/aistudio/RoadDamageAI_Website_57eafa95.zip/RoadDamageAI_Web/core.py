"""RoadDamage AI inference helpers. Never produces synthetic detections."""
from __future__ import annotations

import csv
import io
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageOps

CLASSES = {
    "D00": "Longitudinal crack",
    "D10": "Transverse crack",
    "D20": "Alligator crack",
    "D40": "Pothole",
}

CSV_COLUMNS = [
    "inspection_id", "inspected_at_utc", "source_file", "media_type", "frame_index",
    "time_seconds", "damage_code", "damage_type", "confidence", "x1", "y1",
    "x2", "y2", "image_width", "image_height", "latitude", "longitude",
]


def canonical_code(name: str) -> str | None:
    """Recognize both official RDD codes and common YOLO class labels."""
    text = str(name).casefold().strip()
    cleaned = "".join(ch for ch in text if ch.isalnum())
    if cleaned in {"d00", "longitudinalcrack", "longitudinal"}:
        return "D00"
    if cleaned in {"d10", "transversecrack", "transverse"}:
        return "D10"
    if cleaned in {"d20", "alligatorcrack", "alligator", "alligatorcracking"}:
        return "D20"
    if cleaned in {"d40", "pothole", "potholes"}:
        return "D40"
    return None


def validate_class_mapping(names: dict[int, str] | list[str]) -> dict[int, str]:
    """Reject models trained on unrelated datasets (e.g., generic COCO)."""
    normalized = names if isinstance(names, dict) else dict(enumerate(names))
    mapping: dict[int, str] = {}
    for idx, name in normalized.items():
        code = canonical_code(name)
        if code is None:
            raise ValueError(
                f"Unsupported model class '{name}'. Use a custom RDD2022 model "
                "with D00, D10, D20 and D40 labels."
            )
        mapping[int(idx)] = code
    if len(mapping) != 4 or set(mapping.values()) != set(CLASSES):
        raise ValueError(
            "Model must have exactly four unique road-damage classes: "
            "D00, D10, D20, D40."
        )
    return mapping


def load_rgb(upload: bytes) -> np.ndarray:
    with Image.open(io.BytesIO(upload)) as raw:
        img = ImageOps.exif_transpose(raw).convert("RGB")
        return np.asarray(img)


def get_model(weights: str | Path):
    weights_path = Path(weights)
    if not weights_path.is_file():
        raise FileNotFoundError(f"Custom weights not found: {weights_path}")
    from ultralytics import YOLO
    model = YOLO(str(weights_path))
    mapping = validate_class_mapping(model.names)
    return model, mapping


def predict_frame(
    model: Any,
    frame: np.ndarray,
    mapping: dict[int, str],
    *,
    conf: float = 0.25,
    imgsz: int = 640,
    inspection_id: str = "",
    source_name: str = "",
    media_type: str = "image",
    frame_index: int | None = None,
    time_seconds: float | None = None,
    lat: float | None = None,
    lon: float | None = None,
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    """Run trained model on a BGR image/video frame (OpenCV convention).

    Output is an annotated BGR frame for OpenCV. Detections are observed
    bounding boxes, not independently surveyed road defects.
    """
    result = model.predict(frame, conf=conf, imgsz=imgsz, verbose=False)[0]
    height, width = frame.shape[:2]
    records: list[dict[str, Any]] = []
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    boxes = result.boxes
    if boxes is not None:
        xyxy = boxes.xyxy.cpu().numpy()
        ids = boxes.cls.cpu().numpy().astype(int)
        scores = boxes.conf.cpu().numpy()
        for bb, class_id, score in zip(xyxy, ids, scores):
            if int(class_id) not in mapping:
                raise ValueError(f"Unexpected model class ID: {class_id}")
            code = mapping[int(class_id)]
            x1, y1, x2, y2 = [round(float(v), 2) for v in bb]
            records.append({
                "inspection_id": inspection_id,
                "inspected_at_utc": timestamp,
                "source_file": source_name,
                "media_type": media_type,
                "frame_index": frame_index if frame_index is not None else "",
                "time_seconds": round(time_seconds, 3) if time_seconds is not None else "",
                "damage_code": code,
                "damage_type": CLASSES[code],
                "confidence": round(float(score), 4),
                "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                "image_width": width, "image_height": height,
                "latitude": lat if lat is not None else "",
                "longitude": lon if lon is not None else "",
            })
    return result.plot(), records


def records_to_csv(records: list[dict[str, Any]]) -> bytes:
    data = io.StringIO(newline="")
    writer = csv.DictWriter(data, fieldnames=CSV_COLUMNS, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(records)
    return data.getvalue().encode("utf-8-sig")


def image_to_jpg(bgr: np.ndarray) -> bytes:
    import cv2
    ok, buf = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise OSError("Could not encode annotated JPEG")
    return bytes(buf)


def count_codes(records: list[dict[str, Any]]) -> Counter[str]:
    return Counter(row["damage_code"] for row in records)


def transcode_mp4_for_browser(source: Path) -> Path:
    """Optionally convert OpenCV mp4v to browser-friendly H.264 via FFmpeg.

    Returns source unchanged if FFmpeg is unavailable or transcoding fails.
    """
    import shutil
    import subprocess
    if not shutil.which("ffmpeg"):
        return source
    h264_path = source.with_name(source.stem + "_h264.mp4")
    try:
        result = subprocess.run(
            ["ffmpeg", "-y", "-nostdin", "-hide_banner", "-loglevel", "error",
             "-i", str(source), "-an", "-c:v", "libx264", "-preset", "veryfast",
             "-crf", "24", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
             str(h264_path)], capture_output=True, timeout=300, check=False,
        )
        if result.returncode == 0 and h264_path.exists() and h264_path.stat().st_size > 0:
            return h264_path
    except (OSError, subprocess.TimeoutExpired):
        pass
    return source


def analyze_video(
    model: Any,
    mapping: dict[int, str],
    source: Path,
    dest: Path,
    *,
    inspection_id: str,
    filename: str,
    conf: float = 0.25,
    imgsz: int = 640,
    stride: int = 3,
    lat: float | None = None,
    lon: float | None = None,
    progress=None,
) -> tuple[list[dict[str, Any]], int, int, float]:
    """Draw predictions on sampled video frames and write MP4.

    Un-sampled frames pass through unmodified. Output frame rate remains
    equal to input frame rate; counts are frame observations, not unique holes.
    """
    import cv2

    if stride < 1:
        raise ValueError("stride must be >= 1")
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        raise ValueError("OpenCV could not decode the uploaded video.")
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        if not fps or not np.isfinite(fps) or fps <= 0:
            fps = 25.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if width <= 0 or height <= 0:
            raise ValueError("Could not read video dimensions.")
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(dest), fourcc, fps, (width, height))
        if not writer.isOpened():
            raise RuntimeError("Could not initialize MP4 video writer.")
        records: list[dict[str, Any]] = []
        frame_idx = 0
        analyzed = 0
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if frame_idx % stride == 0:
                    annotated, found = predict_frame(
                        model, frame, mapping, conf=conf, imgsz=imgsz,
                        inspection_id=inspection_id, source_name=filename,
                        media_type="video", frame_index=frame_idx,
                        time_seconds=frame_idx / fps, lat=lat, lon=lon,
                    )
                    records.extend(found)
                    analyzed += 1
                else:
                    annotated = frame
                writer.write(annotated)
                frame_idx += 1
                if progress is not None and frame_idx % 10 == 0:
                    progress(min(frame_idx / max(total, 1), 1.0))
        finally:
            writer.release()
        if frame_idx == 0:
            raise ValueError("The video has no readable frames.")
        if progress:
            progress(1.0)
        return records, frame_idx, analyzed, fps
    finally:
        cap.release()
