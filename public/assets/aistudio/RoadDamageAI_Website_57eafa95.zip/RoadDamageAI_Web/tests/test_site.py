import importlib
import json
from pathlib import Path

from fastapi.testclient import TestClient


def test_routes(tmp_path, monkeypatch):
    monkeypatch.setenv("ROADDAMAGE_DATA_DIR", str(tmp_path / "local_data"))
    monkeypatch.setenv("ROADDAMAGE_WEIGHTS", str(tmp_path / "missing_best.pt"))
    import server
    importlib.reload(server)
    client = TestClient(server.app)
    home = client.get("/")
    assert home.status_code == 200
    assert "RoadDamage AI" in home.text
    assert client.get("/app.js").status_code == 200
    assert client.get("/styles.css").status_code == 200
    health = client.get("/api/health").json()
    assert health["ok"] is True and health["model"]["ready"] is False
    assert client.get("/api/stats").json()["inspections"] == 0
    assert client.post("/api/inspect/image", data={"confidence":"0.25"}, files={"file":("photo.jpg",b"fake","image/jpeg")}).status_code == 409
    saved = client.post("/api/inspections/manual",json={"source_file":"Test Road A", "damage_code":"D40", "severity":"High", "latitude":11.5564,"longitude":104.9282,"note":"Field-observed pothole"})
    assert saved.status_code == 200, saved.text
    item = saved.json()
    assert item["mode"] == "manual" and item["detection_count"] == 0
    assert item["counts"] == {"D40":1}
    assert len(client.get("/api/inspections").json()) == 1
    detail = client.get("/api/inspections/" + item["id"]).json()
    assert detail["note"] == "Field-observed pothole"
    stats = client.get("/api/stats").json()
    assert stats["manual_reports"] == 1 and stats["ai_observations"] == 0
    csvresp = client.get("/api/export/inspections.csv")
    assert csvresp.status_code == 200 and "Test Road A" in csvresp.text
    georesp = client.get("/api/export/inspections.geojson")
    geo = georesp.json()
    assert geo["type"] == "FeatureCollection" and len(geo["features"]) == 1
    assert geo["features"][0]["geometry"]["coordinates"] == [104.9282, 11.5564]
    assert client.post("/api/inspections/manual",json={"source_file":"Test Road B","damage_code":"D50"}).status_code == 422
    assert client.post("/api/inspections/manual",json={"source_file":"Test Road B","damage_code":"D00","latitude":11}).status_code == 422
    assert client.get("/api/files/"+item["id"]+"/csv").status_code == 404
