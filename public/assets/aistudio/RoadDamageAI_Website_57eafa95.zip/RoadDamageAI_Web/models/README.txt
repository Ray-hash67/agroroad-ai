Put the four-class trained YOLO model best.pt here.
