"""RoadDamage AI website API: local-first AI inspection and manual field reports.

The website never fabricates detections. AI endpoints require trained four-class weights.
Run: uvicorn server:app --host 127.0.0.1 --port 8000
"""
from __future__ import annotations

import csv
import io
import json
import os
import sqlite3
import uuid
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

import cv2
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from core import (CLASSES, CSV_COLUMNS, analyze_video, get_model, image_to_jpg,
                  load_rgb, predict_frame, records_to_csv, transcode_mp4_for_browser)

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get("ROADDAMAGE_DATA_DIR", str(ROOT / "data"))).resolve()
WEIGHTS = Path(os.environ.get("ROADDAMAGE_WEIGHTS", str(ROOT / "models" / "best.pt"))).resolve()
OUT = DATA / "outputs"
UPLOADS = DATA / "uploads"
DB_PATH = DATA / "inspections.sqlite3"
for folder in (DATA, OUT, UPLOADS):
    folder.mkdir(parents=True, exist_ok=True)

MAX_IMAGE = 20 * 1024 * 1024
MAX_VIDEO = 100 * 1024 * 1024
ALLOWED_IMAGE = {".jpg", ".jpeg", ".png", ".webp"}
ALLOWED_VIDEO = {".mp4", ".mov", ".avi", ".mkv"}

app = FastAPI(title="RoadDamage AI API", version="1.0.0", docs_url="/api/docs")
_model_lock = Lock()
_cached_model = None
_cached_mapping = None
_cached_stamp = None


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS inspections (
            id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
            source_file TEXT NOT NULL, medium TEXT NOT NULL, mode TEXT NOT NULL,
            latitude REAL, longitude REAL, note TEXT NOT NULL DEFAULT '',
            damage_code TEXT, severity TEXT, detection_count INTEGER NOT NULL DEFAULT 0,
            counts_json TEXT NOT NULL DEFAULT '{}', records_json TEXT NOT NULL DEFAULT '[]',
            annotated_file TEXT, original_file TEXT, csv_file TEXT
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_inspections_created ON inspections(created_at DESC)")


init_db()


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def coords_valid(latitude, longitude):
    if (latitude is None) != (longitude is None):
        raise HTTPException(422, "Enter both latitude and longitude, or neither.")
    if latitude is not None and not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise HTTPException(422, "GPS coordinates are outside valid ranges.")


def status():
    if not WEIGHTS.is_file():
        return {"ready": False, "message": "Custom four-class model missing. Add models/best.pt to enable AI detection."}
    try:
        import ultralytics  # noqa: F401
    except ImportError:
        return {"ready": False, "message": "Install requirements.txt to enable YOLO model inference."}
    return {"ready": True, "message": "Custom weights found. Model will be validated when used."}


def require_model():
    global _cached_model, _cached_mapping, _cached_stamp
    if not status()["ready"]:
        raise HTTPException(status_code=409, detail=status()["message"])
    stamp = WEIGHTS.stat().st_mtime_ns
    with _model_lock:
        if _cached_stamp != stamp:
            try:
                model, mapping = get_model(WEIGHTS)
            except Exception as exc:
                raise HTTPException(422, f"Invalid road-damage model: {exc}") from exc
            _cached_model, _cached_mapping, _cached_stamp = model, mapping, stamp
        return _cached_model, _cached_mapping


def serialize(row, full=False):
    obj = {k: row[k] for k in ("id", "created_at", "source_file", "medium", "mode",
                                 "latitude", "longitude", "note", "damage_code",
                                 "severity", "detection_count")}
    obj["counts"] = json.loads(row["counts_json"])
    obj["files"] = {kind: f"/api/files/{row['id']}/{kind}" for kind, field in
                    [("annotated", "annotated_file"), ("csv", "csv_file"), ("original", "original_file")]
                    if row[field]}
    if full:
        obj["detections"] = json.loads(row["records_json"])
    return obj


def insert_inspection(obj):
    keys = ["id", "created_at", "source_file", "medium", "mode", "latitude", "longitude",
            "note", "damage_code", "severity", "detection_count", "counts_json",
            "records_json", "annotated_file", "original_file", "csv_file"]
    with db() as conn:
        conn.execute(f"INSERT INTO inspections ({', '.join(keys)}) VALUES ({', '.join(['?'] * len(keys))})",
                     [obj.get(k) for k in keys])
        row = conn.execute("SELECT * FROM inspections WHERE id=?", (obj["id"],)).fetchone()
        return serialize(row, full=True)


class ManualInspection(BaseModel):
    source_file: str = Field(default="Field inspection", min_length=2, max_length=120)
    damage_code: str
    severity: str = "Needs review"
    latitude: float | None = None
    longitude: float | None = None
    note: str = Field(default="", max_length=1500)


@app.get("/api/health")
def api_health():
    return {"ok": True, "model": status(), "classes": CLASSES, "mode": "local-first"}


@app.get("/api/inspections")
def inspections(limit: int = 100):
    limit = max(1, min(limit, 500))
    with db() as conn:
        rows = conn.execute("SELECT * FROM inspections ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [serialize(row) for row in rows]


@app.get("/api/inspections/{inspection_id}")
def inspection_detail(inspection_id: str):
    with db() as conn:
        row = conn.execute("SELECT * FROM inspections WHERE id=?", (inspection_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "Inspection not found")
    return serialize(row, full=True)


@app.get("/api/stats")
def stats():
    with db() as conn:
        rows = conn.execute("SELECT * FROM inspections ORDER BY created_at DESC").fetchall()
    counts = Counter()
    ai_count = 0
    manual_count = 0
    locations = 0
    for row in rows:
        counts.update(json.loads(row["counts_json"]))
        ai_count += row["detection_count"] if row["mode"] == "ai" else 0
        manual_count += 1 if row["mode"] == "manual" else 0
        locations += 1 if row["latitude"] is not None and row["longitude"] is not None else 0
    return {"inspections": len(rows), "ai_observations": ai_count, "manual_reports": manual_count,
            "mapped_inspections": locations, "counts": {k: counts[k] for k in CLASSES}}


@app.post("/api/inspections/manual")
def manual_inspection(payload: ManualInspection):
    if payload.damage_code not in CLASSES:
        raise HTTPException(422, "Invalid damage code. Choose D00, D10, D20, or D40.")
    if payload.severity not in {"Needs review", "Low", "Moderate", "High"}:
        raise HTTPException(422, "Invalid severity")
    coords_valid(payload.latitude, payload.longitude)
    uid = uuid.uuid4().hex[:12]
    return insert_inspection({
        "id": uid, "created_at": now_iso(), "source_file": payload.source_file,
        "medium": "field report", "mode": "manual", "latitude": payload.latitude,
        "longitude": payload.longitude, "note": payload.note.strip(),
        "damage_code": payload.damage_code, "severity": payload.severity,
        "detection_count": 0, "counts_json": json.dumps({payload.damage_code: 1}),
        "records_json": "[]", "annotated_file": None, "csv_file": None,
        "original_file": None,
    })


async def read_upload(file: UploadFile, max_bytes: int, allowed: set[str]):
    name = Path(file.filename or "upload").name
    ext = Path(name).suffix.lower()
    if ext not in allowed:
        raise HTTPException(415, f"Unsupported extension {ext or '(none)'}. Allowed: {', '.join(sorted(allowed))}")
    data = await file.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise HTTPException(413, f"File exceeds {max_bytes // 1024 // 1024} MB limit")
    if not data:
        raise HTTPException(400, "File is empty")
    return name[:180], ext, data


@app.post("/api/inspect/image")
async def inspect_image(file: UploadFile = File(...), confidence: float = Form(0.25),
                        latitude: float | None = Form(None), longitude: float | None = Form(None)):
    if not (0.05 <= confidence <= 0.95):
        raise HTTPException(422, "Confidence must be between 0.05 and 0.95")
    coords_valid(latitude, longitude)
    model, mapping = require_model()
    name, ext, data = await read_upload(file, MAX_IMAGE, ALLOWED_IMAGE)
    try:
        rgb = load_rgb(data)
    except Exception as exc:
        raise HTTPException(400, "Image cannot be decoded") from exc
    if rgb.shape[0] * rgb.shape[1] > 25_000_000:
        raise HTTPException(413, "Image is too large (max 25 megapixels)")
    uid = uuid.uuid4().hex[:12]
    original = f"{uid}_original{ext}"
    annotated = f"{uid}_annotated.jpg"
    csv_name = f"{uid}_detections.csv"
    frame = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    try:
        output, records = predict_frame(model, frame, mapping, conf=confidence,
                                        inspection_id=uid, source_name=name, media_type="image",
                                        lat=latitude, lon=longitude)
    except Exception as exc:
        raise HTTPException(500, f"Model inference failed: {exc}") from exc
    (UPLOADS / original).write_bytes(data)
    (OUT / annotated).write_bytes(image_to_jpg(output))
    (OUT / csv_name).write_bytes(records_to_csv(records))
    return insert_inspection({
        "id": uid, "created_at": now_iso(), "source_file": name, "medium": "image",
        "mode": "ai", "latitude": latitude, "longitude": longitude, "note": "",
        "damage_code": None, "severity": None, "detection_count": len(records),
        "counts_json": json.dumps(dict(Counter(row["damage_code"] for row in records))),
        "records_json": json.dumps(records), "annotated_file": annotated,
        "original_file": original, "csv_file": csv_name,
    })


@app.post("/api/inspect/video")
async def inspect_video(file: UploadFile = File(...), confidence: float = Form(0.25),
                        stride: int = Form(3), latitude: float | None = Form(None),
                        longitude: float | None = Form(None)):
    if not (0.05 <= confidence <= 0.95) or not (1 <= stride <= 20):
        raise HTTPException(422, "Invalid confidence or frame stride")
    coords_valid(latitude, longitude)
    model, mapping = require_model()
    name, ext, data = await read_upload(file, MAX_VIDEO, ALLOWED_VIDEO)
    uid = uuid.uuid4().hex[:12]
    original = f"{uid}_original{ext}"
    annotated = f"{uid}_annotated.mp4"
    csv_name = f"{uid}_detections.csv"
    input_path, output_path = UPLOADS / original, OUT / annotated
    input_path.write_bytes(data)
    try:
        records, frames, sampled, fps = analyze_video(model, mapping, input_path, output_path,
            inspection_id=uid, filename=name, conf=confidence, stride=stride,
            lat=latitude, lon=longitude)
    except Exception as exc:
        input_path.unlink(missing_ok=True)
        output_path.unlink(missing_ok=True)
        raise HTTPException(400, f"Video analysis failed: {exc}") from exc
    browser_video = transcode_mp4_for_browser(output_path)
    (OUT / csv_name).write_bytes(records_to_csv(records))
    return insert_inspection({
        "id": uid, "created_at": now_iso(), "source_file": name, "medium": "video",
        "mode": "ai", "latitude": latitude, "longitude": longitude,
        "note": f"Analyzed {sampled} of {frames} frames at {fps:.2f} fps. Repeated observations possible.",
        "damage_code": None, "severity": None, "detection_count": len(records),
        "counts_json": json.dumps(dict(Counter(row["damage_code"] for row in records))),
        "records_json": json.dumps(records), "annotated_file": browser_video.name,
        "original_file": original, "csv_file": csv_name,
    })


@app.get("/api/files/{inspection_id}/{kind}")
def get_file(inspection_id: str, kind: str):
    field_map = {"annotated": "annotated_file", "original": "original_file", "csv": "csv_file"}
    if kind not in field_map:
        raise HTTPException(404, "Unknown file type")
    with db() as conn:
        row = conn.execute("SELECT * FROM inspections WHERE id=?", (inspection_id,)).fetchone()
    if row is None or not row[field_map[kind]]:
        raise HTTPException(404, "File unavailable")
    directory = UPLOADS if kind == "original" else OUT
    file_path = directory / Path(row[field_map[kind]]).name
    if not file_path.is_file():
        raise HTTPException(404, "File missing from storage")
    mime = "text/csv" if kind == "csv" else ("video/mp4" if file_path.suffix == ".mp4" else None)
    return FileResponse(file_path, media_type=mime, filename=file_path.name if kind == "csv" else None)


@app.get("/api/export/inspections.csv")
def export_csv():
    with db() as conn:
        rows = conn.execute("SELECT * FROM inspections ORDER BY created_at DESC").fetchall()
    columns = ["id", "created_at", "source_file", "mode", "medium", "latitude", "longitude",
               "damage_code", "severity", "detection_count", "note", "counts_json"]
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: row[k] for k in columns})
    return Response(content='\ufeff' + stream.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="roaddamage_inspections.csv"'})


@app.get("/api/export/inspections.geojson")
def export_geojson():
    with db() as conn:
        rows = conn.execute("SELECT * FROM inspections WHERE latitude IS NOT NULL AND longitude IS NOT NULL ORDER BY created_at DESC").fetchall()
    features = []
    for row in rows:
        props = serialize(row)
        props.pop("latitude")
        props.pop("longitude")
        props.pop("files")
        props["location_note"] = "Inspection location, not georeferenced defect center"
        features.append({"type":"Feature", "geometry":{"type":"Point", "coordinates":[row["longitude"], row["latitude"]]}, "properties":props})
    content = json.dumps({"type": "FeatureCollection", "features": features}, indent=2)
    return Response(content=content, media_type="application/geo+json",
                    headers={"Content-Disposition": 'attachment; filename="roaddamage_inspections.geojson"'})


app.mount("/", StaticFiles(directory=str(ROOT / "web"), html=True), name="web")
