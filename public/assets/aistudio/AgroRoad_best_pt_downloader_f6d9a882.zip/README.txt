AgroRoad AI - best.pt downloader

IMPORTANT:
This package does NOT include the large model weights themselves yet.
Run download_and_zip_model.py in Google Colab to download best.pt from the
same Hugging Face repository used by your notebook, then create
AgroRoad_best_pt_model.zip containing best.pt.

Steps in Google Colab:
1. Upload this ZIP to Colab and extract it, OR create a new code cell.
2. Install dependencies:
   !pip install -q huggingface_hub
3. Run the contents of download_and_zip_model.py in a cell.
4. Uncomment the last two lines to download the generated ZIP to your computer.

Model source:
https://huggingface.co/dronefreak/rdd2022-yolo26s

Note:
This model is for road-damage object detection. It is not trained specifically
on Cambodian roads unless the model card says so, so test it with local images.
