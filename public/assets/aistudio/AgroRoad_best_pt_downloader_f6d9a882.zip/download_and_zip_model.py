# Run this script in Google Colab or on a computer with internet.
# It downloads the same model used in your notebook and packages best.pt into a ZIP.

from huggingface_hub import hf_hub_download
from pathlib import Path
import zipfile

repo_id = "dronefreak/rdd2022-yolo26s"
weights_path = Path(hf_hub_download(repo_id=repo_id, filename="best.pt"))
zip_path = Path("AgroRoad_best_pt_model.zip")

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    zf.write(weights_path, arcname="best.pt")

print(f"Model downloaded: {weights_path}")
print(f"ZIP created: {zip_path.resolve()}")

# In Google Colab, uncomment these two lines to download the ZIP to your computer:
# from google.colab import files
# files.download(str(zip_path))
